package com.virtusa.collegeapplication.models;

public enum Course {
BE("Bachelor Of Enginnering"),
ME("Master Of Engineering"),
MBA("Master Of Bussiness Administration");
private final String selectCourse;
Course(String selectCourse) {

	this.selectCourse =selectCourse;
}

public String getSelectCourse() {

	return this.selectCourse;
}
}
