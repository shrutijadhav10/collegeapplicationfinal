package com.virtusa.collegeapplication.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AboutController {
	@RequestMapping("/")
	String home() {
		return "views/index";
	}
	@RequestMapping("/aboutUs")
	String aboutUs() {
		return "views/aboutUs"; 
	}
	@RequestMapping("/contactUs")
	String contactUs() {
		return "views/contactUs";
	}
	
	

}
