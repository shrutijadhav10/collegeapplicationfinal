package com.virtusa.collegeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.collegeapplication.models.Submit;

public interface SubmitRepository extends JpaRepository<Submit, Long> {

}
