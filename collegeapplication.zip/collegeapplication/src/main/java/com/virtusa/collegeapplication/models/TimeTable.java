
  package com.virtusa.collegeapplication.models;
  
  import javax.persistence.CascadeType; import javax.persistence.Column; import
  javax.persistence.DiscriminatorColumn; import
  javax.persistence.DiscriminatorType; import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import
  javax.persistence.FetchType; import javax.persistence.GeneratedValue; import
  javax.persistence.GenerationType; import javax.persistence.Id; import
  javax.persistence.Inheritance; import javax.persistence.InheritanceType;
  import javax.persistence.JoinColumn; import javax.persistence.ManyToOne;
  import javax.persistence.Table;
  
  @Entity
  @Inheritance(strategy = InheritanceType.JOINED)
  @Table(name="Timetable") 
  public class TimeTable
  {
  
  @Id  
  @GeneratedValue(strategy=GenerationType.AUTO)
  @Column(name="Id") 
  private Long id;
  
  @Column(name="TimetableType") 
  private String timetableType;
  
  @Column(name="Department")
  @Enumerated(EnumType.STRING)
  private Department department;
  
  @Column(name="Semester") 
  @Enumerated(EnumType.STRING)
  private Semester semester;
  @Column(name="Year") 
  @Enumerated(EnumType.STRING)
  private Year year;
  
  @Column(name="Division") 

  private String division;

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getTimetableType() {
	return timetableType;
}

public void setTimetableType(String timetableType) {
	this.timetableType = timetableType;
}

public Department getDepartment() {
	return department;
}

public void setDepartment(Department department) {
	this.department = department;
}

public Semester getSemester() {
	return semester;
}

public void setSemester(Semester semester) {
	this.semester = semester;
}

public Year getYear() {
	return year;
}

public void setYear(Year year) {
	this.year = year;
}

public String getDivision() {
	return division;
}

public void setDivision(String division) {
	this.division = division;
}

public TimeTable( String timetableType, Department department, Semester semester, Year year, String division) {


	this.timetableType = timetableType;
	this.department = department;
	this.semester = semester;
	this.year = year;
	this.division = division;
}

public TimeTable() {
	// TODO Auto-generated constructor stub
}




  
  }
 