package com.virtusa.collegeapplication.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)

@Table(name="User")
public class User {
	
   
	  @Id

		@Column(name="Email")
		private String email;
		@Column(name="Password")
		private String password;
		
		@Column( name = "ENABLED") 
		  private boolean enabled;
		  
		  @OneToMany(cascade = CascadeType.ALL, mappedBy =
		  "user",fetch=FetchType.LAZY) 
		  @JsonIgnoreProperties("user")
		  private List<UserRole> userRole;

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public boolean isEnabled() {
			return enabled;
		}

		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}

		public List<UserRole> getUserRole() {
			return userRole;
		}

		public void setUserRole(List<UserRole> userRole) {
			this.userRole = userRole;
		}
		  
		  
			
		
	
	
}
