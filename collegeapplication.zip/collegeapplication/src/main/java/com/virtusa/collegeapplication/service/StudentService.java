package com.virtusa.collegeapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.Event;
import com.virtusa.collegeapplication.models.Student;
import com.virtusa.collegeapplication.repository.StudentRepository;


@Service

public class StudentService {
	
	@Autowired
	private StudentRepository studentRepository;
    public Student findStudentByEmail(String email) {
        return studentRepository.findByEmail(email);
       }
       
    public void save(Student student) {
    	studentRepository.save(student);
    }
    public List<Student> listAll() {
        return studentRepository.findAll();
    }
}
