package com.virtusa.collegeapplication.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.virtusa.collegeapplication.models.FacultyTimeTable;
import com.virtusa.collegeapplication.repository.FacultyTimeTableRepository;

@Service
public class TimeTableService {
	
	


}
