package com.virtusa.collegeapplication.controllers;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.Course;
import com.virtusa.collegeapplication.models.Department;
import com.virtusa.collegeapplication.models.Student;
import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.models.UserRole;
import com.virtusa.collegeapplication.repository.UserRepository;
import com.virtusa.collegeapplication.service.AlumniService;
import com.virtusa.collegeapplication.service.UserRoleService;
import com.virtusa.collegeapplication.service.UserService;





@Controller
public class AlumniController {
	@Autowired
	private AlumniService alumniService;
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	
	  
	  @RequestMapping(value = "/alumniRegistration", method = RequestMethod.GET) 
	  public String alumniRegistration(Model model) { 
	      model.addAttribute("alumni", new Alumni());
	      model.addAttribute("departments",Arrays.asList(Department.values()));

	      return "views/alumni_register"; 
	      
	  }
	
	
	
	
	
	
	
	  @RequestMapping(value= "/saveAlumni", method=RequestMethod.POST)
	  public ModelAndView alumniRegistrationSave(@Valid Alumni alumni, BindingResult bindingResult)
	  { 
		  ModelAndView model = new ModelAndView();
		  Alumni userExists =alumniService.findAlumniByEmail(alumni.getEmail());
		  model.addObject("departments",Arrays.asList(Department.values()));
	     
		  if(userExists != null) {
	  
			  bindingResult.rejectValue("email", "error.alumni","This email already exists!"); 
			  model.addObject("msg", "Alumni has been  already  registered!");
			  model.setViewName("views/alumni_register"); 
			  }
	  
		  if(bindingResult.hasErrors())
		  {
			  model.setViewName("views/alumni_register"); 
		  }
		  else 
		  { 
			 
			  alumni.setPassword(new BCryptPasswordEncoder().encode(alumni.getPassword()));
			  alumni.setEnabled(true);
			  alumniService.save(alumni);
	          User user=userService.getUserByEmail(alumni.getEmail());
	          UserRole userRole=new UserRole();
	          userRole.setRole("ROLE_ALUMNI");
	          userRole.setUser(user);
	          userRoleService.save(userRole);
			  
			  	model.addObject("msg", "User has been registered successfully!"); 
			  	model.addObject("alumni", new Alumni()); 
			    model.addObject("department",Department.values());
			    
			  	model.setViewName("views/alumni_register"); 
			  	}
	  
	  return model; 
	  }
		 @RequestMapping("/alumniView/{email}")
		 public ModelAndView viewAlumni(@PathVariable(name = "email") String email) {
			 
		     ModelAndView mav = new ModelAndView("views/alumni_edit");
		     mav.addObject("departments",Arrays.asList(Department.values()));
		    Alumni alumni = alumniService.findAlumniByEmail(email);
		     mav.addObject("alumni",alumni);
		      
		     return mav;
		 }
  
	  
		  @RequestMapping(value = "/alumniUpdate", method = RequestMethod.POST) public
		  String updateAlumni(@ModelAttribute("alumni") Alumni alumni,RedirectAttributes redirAttrs)
		  {
			  redirAttrs.addFlashAttribute("message", "User has been Updated Record successfully!");
		  
			  alumni.setPassword(alumni.getPassword());
			  alumni.setEnabled(true);
		  alumniService.save(alumni); 
		  String  email=alumni.getEmail();
		  return "redirect:/alumniView/"+email; 
		  }
		//show form
		    @RequestMapping(value="/alumniSearch", method=RequestMethod.GET)
		    public String viewAlumniSearch(Model model) {
		       
		    	model.addAttribute("alumni",new Alumni());
		    	model.addAttribute("departments",Arrays.asList(Department.values()));
		    	
		    	return "views/alumniSearch";
		    }
		    
		    
		   // /delete user


	/*
	 * @RequestMapping(value= "/doAlumniSearch", method=RequestMethod.POST) public
	 * ModelAndView doAlumniSearch(@RequestParam("passoutYear") int passoutYear) {
	 * ModelAndView mav = new ModelAndView("views/alumni_search_result");
	 * 
	 * 
	 * 
	 * 
	 * 
	 * List<Alumni> list=alumniService.getAlumniInfoByPassoutYear(passoutYear);
	 * mav.addObject("list",list);
	 * 
	 * return mav; }
	 */
		    
			  
		    @PostMapping("/doAlumniSearch")
			public @ResponseBody List<Alumni>
			findByCustomerId(@RequestBody Alumni alumni)
			{
		    	
			  List<Alumni> list=alumniService.getAlumniInfoByPassoutYear(alumni.getPassoutYear());
				return list;  
		}
  
}
