package com.virtusa.collegeapplication.controllers;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.hibernate.validator.internal.util.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.collegeapplication.configuration.CustomSuccessHandler;
import com.virtusa.collegeapplication.models.Assignment;
import com.virtusa.collegeapplication.models.Department;
import com.virtusa.collegeapplication.models.Faculty;
import com.virtusa.collegeapplication.models.Semester;
import com.virtusa.collegeapplication.models.Student;
import com.virtusa.collegeapplication.models.Submit;
import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.models.Year;
import com.virtusa.collegeapplication.repository.FacultyRepository;
import com.virtusa.collegeapplication.service.AssignmentService;
import com.virtusa.collegeapplication.service.FacultyService;
import com.virtusa.collegeapplication.service.StudentService;
import com.virtusa.collegeapplication.service.SubmitService;

@Controller
public class SubmitController {
	 Logger logger = LogManager.getLogger(SubmitController.class);
	@Autowired
    private SubmitService submitService;
	@Autowired
	private AssignmentService assignmentService;
	@Autowired
	private FacultyService facultyService;
	@Autowired
	private StudentService studentService;
	@Autowired
	HttpSession httpSession;
	 @GetMapping("/submit") 
	 
	
	  public String submit()
	  { 
		 return "views/submit";
		 }
	  
	  @PostMapping("/fileupload")
	    public String fileUpload(@RequestParam("id") Assignment id,@RequestParam("department")Department department,@RequestParam("year") Year year,@RequestParam("division")String division, @RequestParam("file") MultipartFile file,Model mv) {
	        try {
	         logger.info("Id= " + id);
	        	Student student=studentService.findStudentByEmail(httpSession.getAttribute("studentEmail").toString());
	            byte[] image = file.getBytes();
	           Submit model = new Submit(image,id,student,department,year,division);
	           List<Assignment> listAss = assignmentService.listAll();
			   mv.addAttribute("assignment", new Assignment());
			   mv.addAttribute("listAss", listAss );
	            int saveImage = submitService.saveImage(model);
	            if (saveImage == 1) {
	            	mv.addAttribute("message", "Sucessfully Uploaded"); 
	               
	                return "views/assignment";
	            } else {
	                return "error";
	            }
	        } catch (Exception e) {
	            logger.error("ERROR", e);
	            return "error";
	        }
	    }
	  
	  @RequestMapping(value = "/uploadAssignment/{email}") 
	  public ModelAndView uploadAssignment(ModelAndView model,@PathVariable(name = "email")String email) throws IOException
	  {
			  
			
			   model.addObject("assignment", new Assignment());
			   model.addObject("departments",Arrays.asList(Department.values()));
			   model.addObject("semesters",Arrays.asList(Semester.values()));
			   model.addObject("years",Arrays.asList(Year.values()));
			   model.addObject("email",email);
			  model.setViewName("views/facultyAssignment");
			  
			  return model; 
	}
	  
	  @PostMapping("/facultyfileupload")
	    public String facultyfileupload(@RequestParam("email") String email,User user,@RequestParam("semester")Semester semester,@RequestParam("department")Department department,@RequestParam("year") Year year,@RequestParam("division")String division, @RequestParam("file") MultipartFile file,Model mv) {
	        try {
	         //   logger.info("Name= " + name);
	            byte[] image = file.getBytes();
	            Faculty faculty=facultyService.findFacultyByEmail(email);
	           
	            
	            
	            Assignment assignment=new Assignment(image,faculty,department,year,division,semester);
	           
	          
			  
	            int saveImage = assignmentService.saveImage(assignment);
	            if (saveImage == 1) {
	            	mv.addAttribute("message", "Sucessfully Uploaded"); 
	               
	                return "views/facultyAssignment";
	            } else {
	                return "error";
	            }
	        } catch (Exception e) {
	           // logger.error("ERROR", e);
	            return "error";
	        }
	    }

}
