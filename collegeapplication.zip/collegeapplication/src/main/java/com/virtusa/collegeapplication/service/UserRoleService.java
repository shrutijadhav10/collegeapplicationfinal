package com.virtusa.collegeapplication.service;

  import java.util.List;

  
  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.UserRole;

import com.virtusa.collegeapplication.repository.UserRoleRepository;
  
  
  @Service
  
  public class UserRoleService {
  
  @Autowired private UserRoleRepository userRoleRepository;
  
  public List<UserRole> getUserRoleByName(String email) { return
  userRoleRepository.getUserRolesByName(email); }
  
  
  public void save(UserRole  userRole) {
	  userRoleRepository.save(userRole);
  }
  }
 