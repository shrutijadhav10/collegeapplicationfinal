package com.virtusa.collegeapplication.models;

public enum Semester {
	
	FIRSTSEM("FIRSTSEM"),
	SECONDSEM("SECONDSEM"),
	THIRDSEM("THIRDSEM"),
	FOURSEM("FOURSEM"),
	FIFTHSEM("FIFTHSEM"),
	SIXSEM("SIXSEM"),
	SEVENSEM("SEVENSEM"),
	EIGHTSEM("EIGHTSEM");
	private final String selectSemester;
	Semester(String selectSemester) {

		this.selectSemester =selectSemester;
	}

	public String getSelectSemester() {

		return this.selectSemester;
	}

}
