package com.virtusa.collegeapplication.repository;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.ApplicantResult;

public interface ApplicantResultRepository extends JpaRepository<ApplicantResult, String> {
	
    @Query("SELECT ar from ApplicantResult ar where ar.applicant.email= :email")
	ApplicantResult  findByApplicant(@Param("email") String email);
	
}
