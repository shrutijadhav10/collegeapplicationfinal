package com.virtusa.collegeapplication.controllers;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.virtusa.collegeapplication.models.Department;
import com.virtusa.collegeapplication.models.Faculty;
import com.virtusa.collegeapplication.service.FacultyService;

@Controller

public class FacultyController {
	@Autowired
	private FacultyService facultyService;
	@RequestMapping("/facultyProfile/{email}")
	 public ModelAndView showEditProductPage(@PathVariable(name = "email") String email) {
		 
	     ModelAndView mav = new ModelAndView("views/facultyProfile");
	     mav.addObject("departments",Arrays.asList(Department.values()));
	    
	   Faculty faculty = facultyService .findFacultyByEmail(email);
	     mav.addObject("faculty",faculty);
	      
	     return mav;
	 }
	
	@RequestMapping(value =  "/facultyUpdate", method = RequestMethod.POST) 
	 public String updateFaculty(@ModelAttribute("faculty") Faculty faculty,RedirectAttributes redirAttrs)
	  {
		  redirAttrs.addFlashAttribute("message", "Faculty has been Updated Record successfully!");

//System.out.println(student.getPassword());
		  faculty.setPassword(faculty.getPassword());
		  faculty.setEnabled(true);
		  String email=faculty.getEmail();
	 facultyService.save(faculty); 
	  return "redirect:/facultyProfile/"+email; 
	  }


}
