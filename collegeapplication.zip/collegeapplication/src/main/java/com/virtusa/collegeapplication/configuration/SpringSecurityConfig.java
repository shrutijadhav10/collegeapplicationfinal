package com.virtusa.collegeapplication.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration 
  @EnableWebSecurity 
  public class SpringSecurityConfig   extends WebSecurityConfigurerAdapter {
  
  @Autowired 
  private UserDetailsService userDetailsService;
  
  @Autowired 
  private CustomSuccessHandler customSuccessHandler;
  
  @Override protected void configure(AuthenticationManagerBuilder auth) throws
  Exception {
  
  
  auth.userDetailsService(userDetailsService) .passwordEncoder(new
  BCryptPasswordEncoder());
  
  }
  
  @Override protected void configure(HttpSecurity http) throws Exception {
  
	  
  
  http.csrf().disable().authorizeRequests() 
  .antMatchers("/admin").hasRole("ADMIN")
  .antMatchers("/faculty").hasRole("FACULTY")
  .antMatchers("/student").hasRole("STUDENT")
  .antMatchers("/alumni").hasRole("ALUMNI")
  .antMatchers("/applicant").hasRole("APPLICANT")
  .and().formLogin().loginPage("/login").successHandler(customSuccessHandler)
  .failureUrl("/error") .and() .logout().invalidateHttpSession(true).clearAuthentication(true).
  logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/");
  http.sessionManagement().maximumSessions(1);
  
  /*.antMatchers("/admin").access("hasRole('ROLE_ADMIN')")
       .antMatchers("/faculty").access("hasRole('ROLE_FACULTY')")
       .antMatchers("/student").access("hasRole('ROLE_STUDENT')")
       .antMatchers("/alumni").access("hasRole('ROLE_ALUMNI')")
       .antMatchers("/applicant").access("hasRole('ROLE_APPLICANT')")
       
  
  .antMatchers(HttpMethod.GET, "/transaction").hasRole("ADMIN")  
  .antMatchers(HttpMethod.GET,"/transaction").hasRole("FACULTY")
  .antMatchers(HttpMethod.GET,"/transaction").hasRole("STUDENT")
  .antMatchers(HttpMethod.GET,"/transaction").hasRole("ALUMNI")
  .antMatchers(HttpMethod.GET,"/transaction").hasRole("APPLICANT")
  .and() .formLogin()
  .loginPage("/login").successHandler(customSuccessHandler)
  .failureUrl("/error") .and() .logout() .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
  .logoutSuccessUrl("/").invalidateHttpSession(true);*/
  
  }
  @Bean
  public HttpSessionEventPublisher httpSessionEventPublisher()
  {
	  return new HttpSessionEventPublisher();
  }
  
  
  }
 