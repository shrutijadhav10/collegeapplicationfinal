package com.virtusa.collegeapplication.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.Assignment;
import com.virtusa.collegeapplication.models.Submit;
import com.virtusa.collegeapplication.repository.SubmitRepository;

@Service
public class SubmitService {
	 private static Logger logger = (Logger) LogManager.getLogger( SubmitService.class) ;
	 @Autowired
	    private SubmitRepository submitRepository;

	    public int saveImage(Submit model) {
	        try {
	        	submitRepository.save(model);
	            return 1;
	        } catch (Exception e) {
	            logger.error("ERROR", e);
	            return 0;
	        }
	    }
	    public List<Submit> listAll() {
	        return submitRepository.findAll();
	    }
	    
	    public Submit getFile(long id) {
	        return submitRepository.findById(id)
	        		.orElseThrow(() -> new MyFileNotFoundException("File not found with id " + id));
	    }
}
