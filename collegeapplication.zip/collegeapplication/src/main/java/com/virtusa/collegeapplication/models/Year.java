package com.virtusa.collegeapplication.models;

public enum Year 
{
	FIRSTYEAR("FIRSTYEAR"),
	SECONDYEAR("SECONDYEAR"),
	THIRDYEAR("THIRDYEAR"),
	FOURYEAR("THIRDYEAR");
	
	private final String selectYear;
	Year(String selectYear) {

		this.selectYear =selectYear;
	}

	public String getSelectYear() {

		return this.selectYear;
	}
}
