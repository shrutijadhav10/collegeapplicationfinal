package com.virtusa.collegeapplication.controllers;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.service.UserRoleService;
import com.virtusa.collegeapplication.service.UserService;


@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	HttpSession httpSession;
	
	@GetMapping("/admin")
	public ModelAndView admin()
	{
		
		ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        User user=userService.getUserByEmail(auth.getName());
        SecurityContext context = SecurityContextHolder.getContext();
        modelAndView.addObject("email", context.getAuthentication().getName());
        
       // modelAndView.addObject("email",user.getEmail()+" =====  logged in as Admin" );
        modelAndView.setViewName("views/adminHome");
        return modelAndView;
	}
	

	@GetMapping("/student")
	public ModelAndView student()
	{
		
		ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        User user=userService.getUserByEmail(auth.getName());
        httpSession.setAttribute("studentEmail", auth.getName());
        
        String email=user.getEmail();
        
        
        modelAndView.addObject("email",user.getEmail()+" =====  logged in as Student" );
        return new ModelAndView("redirect:/studentProfile/");
	}
	@GetMapping("/alumni")
	public ModelAndView alumni()
	{
		
		ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        User user=userService.getUserByEmail(auth.getName());
        String email=user.getEmail();
        
        
        modelAndView.addObject("email",user.getEmail()+" =====  logged in as Alumni" );
        //modelAndView.setViewName("alumniHome");
		return new ModelAndView("redirect:/alumniView/"+email);
	}
	@GetMapping("/applicant")
	public ModelAndView applicant()
	{
		
		ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        User user=userService.getUserByEmail(auth.getName());
        String email=user.getEmail();
        
        
        modelAndView.addObject("email",user.getEmail()+" =====  logged in as Applicant" );
        //modelAndView.setViewName("alumniHome");
		return new ModelAndView("redirect:/applicantView/"+email);
	}
	@GetMapping("/faculty")
	public ModelAndView faculty()
	{
		
		ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        User user=userService.getUserByEmail(auth.getName());
        
        String email=user.getEmail();
        
        modelAndView.addObject("username",user.getEmail()+" =====  logged in as Faculty" );
        return new ModelAndView("redirect:/facultyProfile/"+email);
	}
 
	

}
