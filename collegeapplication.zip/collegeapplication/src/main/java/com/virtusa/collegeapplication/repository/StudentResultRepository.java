package com.virtusa.collegeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.virtusa.collegeapplication.models.StudentResult;

public interface StudentResultRepository extends JpaRepository<StudentResult, String> {
	
    @Query("SELECT sr from StudentResult sr where sr.student.email= :email")
	StudentResult  findByStudent(@Param("email") String email);
}
