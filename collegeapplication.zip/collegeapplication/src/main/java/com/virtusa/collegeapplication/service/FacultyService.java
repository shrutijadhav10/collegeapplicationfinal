package com.virtusa.collegeapplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.Faculty;

import com.virtusa.collegeapplication.repository.FacultyRepository;

@Service
public class FacultyService {
	@Autowired
	private FacultyRepository facultyRepository;
	public Faculty findFacultyByEmail(String email) {
        return facultyRepository.findByEmail(email);
       }
       
    public void save(Faculty faculty) {
    	facultyRepository.save(faculty);
    }
}
