package com.virtusa.collegeapplication.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name ="ApplicantResult") 
public class ApplicantResult {
	 @Id
	  @GeneratedValue(strategy=GenerationType.AUTO)
	  @Column(name="Id") 
	  private Long id;
	 @OneToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY) 
	  private Applicant applicant;
	  @Column(name="Status")
	  private boolean status;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Applicant getApplicant() {
		return applicant;
	}
	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	
	  @Override
	    public String toString() {
	        return String.format(
	        		
	        		
	        		
	                "%s",
	                applicant.getEmail() );
	    }
	

}
