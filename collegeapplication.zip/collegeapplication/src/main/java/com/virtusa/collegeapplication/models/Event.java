
  package com.virtusa.collegeapplication.models;
  
  import java.time.LocalDate;

import javax.persistence.CascadeType; import javax.persistence.Column; import
  javax.persistence.DiscriminatorColumn; import
  javax.persistence.DiscriminatorType; import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import
  javax.persistence.FetchType; import javax.persistence.GeneratedValue; import
  javax.persistence.GenerationType; import javax.persistence.Id; import
  javax.persistence.Inheritance; import javax.persistence.InheritanceType;
  import javax.persistence.JoinColumn; import javax.persistence.ManyToOne;
  import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
  
  @Entity
  @Inheritance(strategy = InheritanceType.JOINED)
  @Table(name="Event") 
  public class Event 
  {
  
  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  @Column(name="Id") 
  private Long id;
  
  @Column(name="EventType") 
  @Enumerated(EnumType.STRING)
  private EventType eventType;
  @Column(name="EventName")
  private String eventName;
  @Column(name="EventDate")
  @DateTimeFormat(iso = ISO.DATE)
  private LocalDate eventDate;
  @Column(name="CoordinatorName")
  private String coordinatorName;
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public EventType getEventType() {
	return eventType;
}
public void setEventType(EventType eventType) {
	this.eventType = eventType;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
public LocalDate getEventDate() {
	return eventDate;
}
public void setEventDate(LocalDate eventDate) {
	this.eventDate = eventDate;
}
public String getCoordinatorName() {
	return coordinatorName;
}
public void setCoordinatorName(String coordinatorName) {
	this.coordinatorName = coordinatorName;
}

  
 
  
 
  
  
  }
 