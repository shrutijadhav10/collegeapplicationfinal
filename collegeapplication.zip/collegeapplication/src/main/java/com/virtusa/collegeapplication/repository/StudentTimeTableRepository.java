package com.virtusa.collegeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.collegeapplication.models.StudentTimeTable;

public interface StudentTimeTableRepository extends JpaRepository<StudentTimeTable, Long>{

}
