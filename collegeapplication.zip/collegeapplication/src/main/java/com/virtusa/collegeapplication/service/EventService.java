package com.virtusa.collegeapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.Event;
import com.virtusa.collegeapplication.repository.EventRepository;

@Service

public class EventService {

	
	@Autowired
	private EventRepository eventRepository;
	
	 public List<Event> listAllEvent() {
	        return eventRepository.findAll();
	    }
	 public void save(Event event) {
		 eventRepository.save(event);
	    }
	 
	 public List<Event> getEventInfoByEventType(String eventType) {
	    	List<Event> event= eventRepository.getEventInfoByEventType(eventType);
	    	//System.out.println(event.size());
			return event;
		}
}
